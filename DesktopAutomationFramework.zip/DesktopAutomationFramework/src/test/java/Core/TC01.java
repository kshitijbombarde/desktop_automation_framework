package Core;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.winium.DesktopOptions;
import org.openqa.selenium.winium.WiniumDriver;

public class TC01 {

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		// TODO Auto-generated method stub
		DesktopOptions options = new DesktopOptions();
		
		options.setApplicationPath("C:/Windows/System32/calc.exe");
		Thread.sleep(5000);
		WiniumDriver driver = new WiniumDriver(new URL("http://localhost:9999"), options);
		
		driver.findElement(By.id("num7Button")).click();
		driver.findElement(By.id("plusButton")).click();
		driver.findElement(By.id("num8Button")).click();
		driver.findElement(By.id("equalButton")).click();
		captureScreen("capture01");
		String output = driver.findElement(By.id("CalculatorResults")).getAttribute("Name").toString();
		
		if(output.equals("Display is 15")) {
			System.out.println("TC01 Pass!");
		}
		else {
			System.out.println("TC01 Fail!");
		}
	}
	
	static void captureScreen(String captureName) {
		try {
			Robot robo = new Robot();
			Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
			Rectangle rect = new Rectangle(dim);
			BufferedImage buffImg = robo.createScreenCapture(rect);
			ImageIO.write(buffImg, "PNG", new File("./Screenshots/"+captureName+".png"));
			System.out.println("Screen Captured !");
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

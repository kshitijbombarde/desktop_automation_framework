package testSuite;

import org.testng.annotations.Test;

import testCases.BaseClass;
import testCases.TC01_AdditionTest;
import testCases.TC02_SubtractionTest;

public class TestSuite extends BaseClass {

	public TC01_AdditionTest  tc01= new TC01_AdditionTest();
	public TC02_SubtractionTest  tc02= new TC02_SubtractionTest();
	
	
	@Test(priority=1)
	public void addition() {
		tc01.additionTest();
	}
	
	@Test(priority=2)
	public void subtraction() {
		tc02.subtractionTest();
	}
	
	
}

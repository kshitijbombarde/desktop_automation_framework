package testCases;

import org.testng.Assert;

import screenObjects.CalcScreen;

public class TC01_AdditionTest extends BaseClass{

	public void additionTest() {
		CalcScreen cs = new CalcScreen(driver);
		cs.click7();
		cs.clickPlus();
		cs.click8();
		cs.clickEqual();
		captureScreen("addition");
		if(cs.getResults().equals("Display is 15")) {
			Assert.assertTrue(true);
			System.out.println("Test Passed !");
		}
		else {
			Assert.assertTrue(false);
			System.out.println("Test Failed !");
		}
		
	}
	
	
}

package testCases;

import org.testng.Assert;

import screenObjects.CalcScreen;

public class TC02_SubtractionTest extends BaseClass {
	
	public void subtractionTest() {
		CalcScreen cs = new CalcScreen(driver);
		cs.click8();
		cs.clickMinus();
		cs.click7();
		cs.clickEqual();
		captureScreen("subtraction");
		
		if(cs.getResults().equals("Display is 1")) {
			Assert.assertTrue(true);
			System.out.println("Test Passed !");
		}
		else {
			Assert.assertTrue(false);
			System.out.println("Test Failed !");
		}
		
	}
	
}

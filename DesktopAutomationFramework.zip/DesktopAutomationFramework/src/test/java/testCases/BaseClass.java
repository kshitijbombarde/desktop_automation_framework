package testCases;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Timestamp;

import javax.imageio.ImageIO;

import org.openqa.selenium.winium.DesktopOptions;
import org.openqa.selenium.winium.WiniumDriver;
//import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import Core.readConfig;

public class BaseClass {

	readConfig readconfig = new readConfig();
	
	//getProperties
	public String appServer = readconfig.getAppServer();
	public String appLocation = readconfig.getAppLocation();
	public String screenCaptureDir = readconfig.getScreenCaptureDir();
	
	//base
	public static WiniumDriver driver;
	
	@BeforeClass
	public void setup() throws MalformedURLException {
		DesktopOptions options = new DesktopOptions();
		
		options.setApplicationPath(appLocation);
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		driver = new WiniumDriver(new URL(appServer), options);
	}
	
//	@AfterClass
//	public void teardown() {
//		driver.quit();
//	}
	
	static void captureScreen(String captureName) {
		try {
			Timestamp ts = new Timestamp(System.currentTimeMillis());
			System.out.println(ts);
			Robot robo = new Robot();
			Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
			Rectangle rect = new Rectangle(dim);
			BufferedImage buffImg = robo.createScreenCapture(rect);
			ImageIO.write(buffImg, "PNG", new File("./Screenshots/"+captureName+".png"));
			System.out.println("Screen Captured !");
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}

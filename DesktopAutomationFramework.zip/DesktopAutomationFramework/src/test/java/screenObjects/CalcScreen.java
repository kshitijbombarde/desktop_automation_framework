package screenObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.winium.WiniumDriver;

public class CalcScreen {

	WiniumDriver ldriver;
	public CalcScreen(WiniumDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	//ScreenObjects
	@FindBy(id="num7Button")
	WebElement numBtn7;
	
	@FindBy(id="num8Button")
	WebElement numBtn8;
	
	@FindBy(id="plusButton")
	WebElement opsBtnPlus;
	
	@FindBy(id="minusButton")
	WebElement opsBtnMinus;
	
	@FindBy(id="equalButton")
	WebElement opsBtnEquals;
	
	@FindBy(id="CalculatorResults")
	WebElement displayResults;
	
	//ActionMethods
	public void click7() {
		numBtn7.click();
	}
	
	public void click8() {
		numBtn8.click();
	}
	
	public void clickPlus() {
		opsBtnPlus.click();
	}
	
	public void clickMinus() {
		opsBtnMinus.click();
	}
	
	
	public void clickEqual() {
		opsBtnEquals.click();
	}
	
	public String getResults() {
		String results = displayResults.getAttribute("Name").toString();
		return results;
	}
	
}
